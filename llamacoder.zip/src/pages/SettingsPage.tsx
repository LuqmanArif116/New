import React from 'react';
import { Settings as SettingsIcon, User, Shield, Mail } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { User as UserType } from '../types';
import { formatDate } from '../utils/helpers';

interface SettingsPageProps {
  user: UserType | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ user, onNavigate, onLogout }) => {
  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to access settings</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-3">
        <SettingsIcon className="w-8 h-8" /> Settings
      </h1>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" /> Account Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3 p-4 bg-slate-800 rounded-lg">
            <Mail className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm text-slate-400">Email</p>
              <p className="font-medium">{user.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-slate-800 rounded-lg">
            <Shield className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm text-slate-400">Account Type</p>
              <p className="font-medium flex items-center gap-2">
                {user.role === 'verified_seller' ? (
                  <>
                    <span className="bg-emerald-500 text-xs px-2 py-1 rounded-full">Verified Seller</span>
                  </>
                ) : (
                  <span className="bg-slate-700 text-xs px-2 py-1 rounded-full">Buyer</span>
                )}
              </p>
            </div>
          </div>

          <div className="p-4 bg-slate-800 rounded-lg">
            <p className="text-sm text-slate-400">Member Since</p>
            <p className="font-medium">{formatDate(user.createdAt)}</p>
          </div>

          <div className="p-4 bg-slate-800 rounded-lg">
            <p className="text-sm text-slate-400">Total Orders</p>
            <p className="font-medium">{user.orders.length}</p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Danger Zone</CardTitle>
          <CardDescription>Irreversible actions</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={onLogout} className="bg-red-500 hover:bg-red-600">
            Logout
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};