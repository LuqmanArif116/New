import React, { useState } from 'react';
import { ArrowLeft, Check, ShoppingCart, Heart, Star } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Product, User } from '../types';
import { formatPrice, formatDate } from '../utils/helpers';
import { PLATFORM_COLORS, PLATFORM_ICONS } from '../utils/constants';

interface ProductDetailPageProps {
  product: Product;
  user: User | null;
  onNavigate: (page: string) => void;
  onAddToCart: (product: Product) => void;
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
  onUpdateUser: (user: User) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  user,
  onNavigate,
  onAddToCart,
  onNotify,
  onUpdateUser
}) => {
  const platformColor = PLATFORM_COLORS[product.platform] || 'from-slate-600 to-slate-700';
  const platformIcon = PLATFORM_ICONS[product.platform] || '📱';

  const isFavorite = user?.favorites.includes(product.id);

  const handleToggleFavorite = () => {
    if (!user) {
      onNotify('Please login to add favorites', 'error');
      return;
    }

    const updatedUser = {
      ...user,
      favorites: isFavorite
        ? user.favorites.filter(id => id !== product.id)
        : [...user.favorites, product.id]
    };
    onUpdateUser(updatedUser);
    onNotify(isFavorite ? 'Removed from favorites' : 'Added to favorites', 'success');
  };

  const handleAddToCart = () => {
    if (!user) {
      onNotify('Please login to add to cart', 'error');
      onNavigate('login');
      return;
    }
    onAddToCart(product);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Button
        onClick={() => onNavigate('products')}
        variant="outline"
        className="mb-6 border-slate-700 text-slate-300 hover:bg-slate-800"
      >
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Products
      </Button>

      <Card className="bg-slate-900 border-slate-800 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          <div className={`h-64 md:h-auto bg-gradient-to-br ${platformColor} flex items-center justify-center`}>
            <span className="text-8xl">{platformIcon}</span>
          </div>

          <div>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{product.name}</CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="bg-slate-800 px-3 py-1 rounded-full text-sm capitalize">
                      {product.platform}
                    </span>
                    {product.isVerified && (
                      <span className="bg-emerald-500 px-3 py-1 rounded-full text-sm flex items-center gap-1">
                        <Check className="w-4 h-4" /> Verified Seller
                      </span>
                    )}
                  </div>
                </div>
                <button
                  onClick={handleToggleFavorite}
                  className={`p-2 rounded-lg transition-colors ${isFavorite ? 'bg-pink-500' : 'bg-slate-800 hover:bg-slate-700'}`}
                >
                  <Heart className={`w-5 h-5 ${isFavorite ? 'fill-white' : ''}`} />
                </button>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <p className="text-slate-400">{product.description}</p>

              <div className="flex flex-wrap gap-2">
                {product.features.map((feature, i) => (
                  <span key={i} className="bg-slate-800 px-3 py-1 rounded-full text-sm">
                    {feature}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-4 text-sm text-slate-400">
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> {product.soldCount} sold
                </span>
                <span>Listed: {formatDate(product.createdAt)}</span>
              </div>

              <div className="border-t border-slate-800 pt-4">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-slate-400">Price:</span>
                  <span className="text-amber-400 font-bold text-3xl">{formatPrice(product.price)}</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <span className="text-slate-400">Stock:</span>
                  <span className={product.stock <= 3 ? 'text-red-400' : 'text-emerald-400'}>
                    {product.stock} available
                  </span>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={handleAddToCart}
                    disabled={product.stock === 0}
                    className="w-full bg-violet-500 hover:bg-violet-600 disabled:bg-slate-700 py-6"
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                  </Button>
                  <p className="text-xs text-slate-500 text-center">
                    Seller: {product.sellerEmail}
                  </p>
                </div>
              </div>
            </CardContent>
          </div>
        </div>
      </Card>
    </div>
  );
};