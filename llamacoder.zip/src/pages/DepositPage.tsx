import React, { useState } from 'react';
import { Wallet, Send } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { User } from '../types';
import { DEPOSIT_KEYS, TELEGRAM_USERNAME } from '../utils/constants';
import { saveUserToStorage } from '../utils/helpers';

interface DepositPageProps {
  user: User | null;
  onUpdateUser: (user: User) => void;
  onNotify: (message: string) => void;
}

export const DepositPage: React.FC<DepositPageProps> = ({ user, onUpdateUser, onNotify }) => {
  const [depositKey, setDepositKey] = useState('');
  const [amount, setAmount] = useState('');

  const handleDeposit = () => {
    if (!user) {
      onNotify('Please login first');
      return;
    }

    if (!DEPOSIT_KEYS.includes(depositKey)) {
      onNotify('Invalid deposit key');
      return;
    }

    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      onNotify('Please enter a valid amount');
      return;
    }

    const updatedUser = { ...user, balance: user.balance + depositAmount };
    onUpdateUser(updatedUser);
    saveUserToStorage(updatedUser);
    onNotify(`Successfully deposited $${depositAmount.toFixed(2)}!`);
    setDepositKey('');
    setAmount('');
  };

  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to access deposit</p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto">
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Wallet className="w-6 h-6" /> Deposit Funds
          </CardTitle>
          <CardDescription>Add funds to your wallet</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-slate-800 rounded-lg p-4 text-center">
            <p className="text-slate-400">Current Balance</p>
            <p className="text-3xl font-bold text-amber-400">${user.balance.toFixed(2)}</p>
          </div>

          <div>
            <Label htmlFor="amount">Amount ($)</Label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="Enter amount"
              className="bg-slate-800 border-slate-700 mt-1"
            />
          </div>

          <div>
            <Label htmlFor="depositKey">Deposit Key</Label>
            <Input
              id="depositKey"
              type="text"
              value={depositKey}
              onChange={e => setDepositKey(e.target.value)}
              placeholder="Enter your deposit key"
              className="bg-slate-800 border-slate-700 mt-1"
            />
          </div>

          <div className="bg-amber-500 bg-opacity-10 border border-amber-500 rounded-lg p-4">
            <p className="text-amber-400 text-sm">For deposit activation and verification, contact us on Telegram</p>
            <a
              href={`https://t.me/${TELEGRAM_USERNAME}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center gap-2 bg-sky-500 hover:bg-sky-600 px-4 py-2 rounded-lg transition-colors"
            >
              <Send className="w-4 h-4" /> Contact on Telegram
            </a>
          </div>

          <Button onClick={handleDeposit} className="w-full bg-emerald-500 hover:bg-emerald-600 py-6">
            Deposit Funds
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};