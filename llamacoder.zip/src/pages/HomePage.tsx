import React from 'react';
import { ArrowRight, Send, Star, TrendingUp, Shield, Clock, Zap } from 'lucide-react';
import { Button } from '../components/ui/button';
import { ProductCard } from '../components/ProductCard';
import { Product, User } from '../types';
import { TELEGRAM_USERNAME } from '../utils/constants';

interface HomePageProps {
  products: Product[];
  user: User | null;
  onNavigate: (page: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ products, user, onNavigate, onSelectProduct, onAddToCart }) => {
  const featuredProducts = products.filter(p => p.isVerified).slice(0, 4);
  const recentProducts = [...products].sort((a, b) => b.createdAt - a.createdAt).slice(0, 8);

  const stats = [
    { label: 'Active Products', value: products.length, color: 'text-violet-400', icon: <TrendingUp className="w-5 h-5" /> },
    { label: 'Verified Sellers', value: '50+', color: 'text-emerald-400', icon: <Shield className="w-5 h-5" /> },
    { label: 'Accounts Sold', value: '1,200+', color: 'text-amber-400', icon: <Zap className="w-5 h-5" /> },
    { label: 'Fast Delivery', value: 'Instant', color: 'text-pink-400', icon: <Clock className="w-5 h-5" /> }
  ];

  return (
    <div className="space-y-16">
      <section className="text-center py-16">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400 bg-clip-text text-transparent">
            Buy & Sell
          </span>
          <br />
          <span className="text-white">Social Media Accounts</span>
        </h1>
        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-10">
          The most trusted marketplace for Facebook, Instagram, LinkedIn & Threads accounts.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Button onClick={() => onNavigate('products')} className="bg-violet-500 hover:bg-violet-600 px-10 py-7 text-lg">
            Browse Products <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <a
            href={`https://t.me/${TELEGRAM_USERNAME}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-slate-800 hover:bg-slate-700 px-10 py-7 rounded-lg text-lg flex items-center gap-3 transition-colors border border-slate-700"
          >
            <Send className="w-5 h-5" /> Contact Support
          </a>
        </div>
      </section>

      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center hover:border-violet-500 transition-colors">
            <div className={`flex justify-center mb-2 ${stat.color}`}>{stat.icon}</div>
            <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
            <p className="text-slate-400 mt-1 text-sm">{stat.label}</p>
          </div>
        ))}
      </section>

      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <Star className="w-6 h-6 text-amber-400" /> Featured Products
          </h2>
          <Button onClick={() => onNavigate('products')} variant="outline" className="border-slate-700 text-slate-300">
            View All <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              user={user}
              onSelect={onSelectProduct}
              onNavigate={onNavigate}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Recent Listings</h2>
          <Button onClick={() => onNavigate('products')} variant="outline" className="border-slate-700 text-slate-300">
            View All <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {recentProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              user={user}
              onSelect={onSelectProduct}
              onNavigate={onNavigate}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>
    </div>
  );
};