import React, { useState } from 'react';
import { Wallet } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { User } from '../types';
import { saveUserToStorage } from '../utils/helpers';

interface WithdrawPageProps {
  user: User | null;
  onUpdateUser: (user: User) => void;
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const WithdrawPage: React.FC<WithdrawPageProps> = ({ user, onUpdateUser, onNotify }) => {
  const [amount, setAmount] = useState('');
  const [address, setAddress] = useState('');

  const handleWithdraw = () => {
    if (!user) return;

    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      onNotify('Please enter a valid amount', 'error');
      return;
    }

    if (withdrawAmount > user.balance) {
      onNotify('Insufficient balance', 'error');
      return;
    }

    if (!address) {
      onNotify('Please enter withdrawal address', 'error');
      return;
    }

    const updatedUser = { ...user, balance: user.balance - withdrawAmount };
    onUpdateUser(updatedUser);
    saveUserToStorage(updatedUser);
    onNotify(`Withdrawal of $${withdrawAmount.toFixed(2)} submitted!`, 'success');
    setAmount('');
    setAddress('');
  };

  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to access withdrawal</p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto">
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Wallet className="w-6 h-6" /> Withdraw Funds
          </CardTitle>
          <CardDescription>Withdraw to your external wallet</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-slate-800 rounded-lg p-4 text-center">
            <p className="text-slate-400">Available Balance</p>
            <p className="text-3xl font-bold text-amber-400">${user.balance.toFixed(2)}</p>
          </div>

          <div>
            <Label htmlFor="withdrawAmount">Amount ($)</Label>
            <Input
              id="withdrawAmount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              className="bg-slate-800 border-slate-700 mt-1"
            />
          </div>

          <div>
            <Label htmlFor="withdrawAddress">Wallet Address</Label>
            <Input
              id="withdrawAddress"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter your wallet address"
              className="bg-slate-800 border-slate-700 mt-1"
            />
          </div>

          <Button onClick={handleWithdraw} className="w-full bg-violet-500 hover:bg-violet-600 py-6">
            Withdraw
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};