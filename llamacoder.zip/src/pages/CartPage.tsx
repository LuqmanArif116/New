import React from 'react';
import { ShoppingCart, Trash2 } from 'lucide-react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { User, CartItem } from '../types';
import { formatPrice } from '../utils/helpers';

interface CartPageProps {
  cart: CartItem[];
  user: User | null;
  onNavigate: (page: string) => void;
  onRemove: (productId: string) => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onPurchase: () => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  cart,
  user,
  onNavigate,
  onRemove,
  onUpdateQuantity,
  onPurchase
}) => {
  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to view cart</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-3">
        <ShoppingCart className="w-8 h-8" /> Shopping Cart
      </h1>

      {cart.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-xl border border-slate-800">
          <ShoppingCart className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <p className="text-slate-400">Your cart is empty</p>
          <Button onClick={() => onNavigate('products')} className="mt-4 bg-violet-500 hover:bg-violet-600">
            Browse Products
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {cart.map(item => (
              <Card key={item.product.id} className="bg-slate-900 border-slate-800">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className="w-20 h-20 bg-slate-800 rounded-lg flex items-center justify-center text-2xl">
                      {item.product.platform.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold">{item.product.name}</h3>
                      <p className="text-slate-400 text-sm">{item.product.description.substring(0, 50)}...</p>
                      <p className="text-amber-400 font-bold mt-1">{formatPrice(item.product.price)}</p>
                    </div>
                    <div className="flex flex-col items-end justify-between">
                      <button
                        onClick={() => onRemove(item.product.id)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                          className="w-8 h-8 bg-slate-800 rounded-lg hover:bg-slate-700"
                        >
                          -
                        </button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                          className="w-8 h-8 bg-slate-800 rounded-lg hover:bg-slate-700"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="lg:col-span-1">
            <Card className="bg-slate-900 border-slate-800 sticky top-24">
              <CardContent className="p-6 space-y-4">
                <h3 className="text-xl font-bold">Order Summary</h3>
                <div className="flex justify-between text-slate-400">
                  <span>Items ({cart.reduce((sum, item) => sum + item.quantity, 0)})</span>
                  <span>{formatPrice(total)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Your Balance</span>
                  <span className="text-amber-400">{formatPrice(user.balance)}</span>
                </div>
                <div className="border-t border-slate-800 pt-4">
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-amber-400">{formatPrice(total)}</span>
                  </div>
                </div>
                <Button
                  onClick={onPurchase}
                  disabled={user.balance < total}
                  className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-700 disabled:text-slate-500 py-6"
                >
                  {user.balance < total ? 'Insufficient Balance' : 'Complete Purchase'}
                </Button>
                {user.balance < total && (
                  <Button
                    onClick={() => onNavigate('deposit')}
                    variant="outline"
                    className="w-full border-slate-700"
                  >
                    Add Funds
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};