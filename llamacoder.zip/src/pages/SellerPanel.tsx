import React, { useState } from 'react';
import { Store, Plus } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Button } from '../components/ui/button';
import { User, Product } from '../types';
import { PLATFORMS } from '../utils/constants';
import { generateId } from '../utils/helpers';

interface SellerPanelProps {
  user: User | null;
  onNavigate: (page: string) => void;
  onAddProduct: (product: Product) => void;
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const SellerPanel: React.FC<SellerPanelProps> = ({ user, onNavigate, onAddProduct, onNotify }) => {
  const [name, setName] = useState('');
  const [platform, setPlatform] = useState<'facebook' | 'instagram' | 'linkedin' | 'threads'>('facebook');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [credentials, setCredentials] = useState('');
  const [deliveryInfo, setDeliveryInfo] = useState('Instant delivery - credentials displayed immediately');
  const [stock, setStock] = useState('1');
  const [features, setFeatures] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      onNotify('Please login first', 'error');
      return;
    }

    if (!name || !price || !description || !credentials) {
      onNotify('Please fill all required fields', 'error');
      return;
    }

    const newProduct: Product = {
      id: generateId(),
      name,
      platform,
      price: parseFloat(price),
      description,
      sellerId: user.id,
      sellerEmail: user.email,
      isVerified: user.role === 'verified_seller',
      credentials,
      deliveryInfo,
      stock: parseInt(stock) || 1,
      soldCount: 0,
      createdAt: Date.now(),
      features: features.split(',').map(f => f.trim()).filter(f => f)
    };

    onAddProduct(newProduct);
    onNotify('Product listed successfully!', 'success');
    
    setName('');
    setPrice('');
    setDescription('');
    setCredentials('');
    setFeatures('');
    setStock('1');
  };

  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to access seller panel</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-3">
        <Store className="w-8 h-8" /> Seller Panel
      </h1>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5" /> List New Product
          </CardTitle>
          <CardDescription>
            {user.role === 'verified_seller' 
              ? '✓ Your products will be marked as verified'
              : 'Products will be listed as unverified. Contact support to get verified.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Facebook Business Account - 10K Followers"
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>

            <div>
              <Label htmlFor="platform">Platform *</Label>
              <select
                id="platform"
                value={platform}
                onChange={(e) => setPlatform(e.target.value as typeof platform)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 mt-1"
              >
                {PLATFORMS.map(p => (
                  <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>
                ))}
              </select>
            </div>

            <div>
              <Label htmlFor="price">Price ($) *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="29.99"
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your product..."
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>

            <div>
              <Label htmlFor="credentials">Account Credentials *</Label>
              <Textarea
                id="credentials"
                value={credentials}
                onChange={(e) => setCredentials(e.target.value)}
                placeholder="Email: example@email.com&#10;Password: password123"
                className="bg-slate-800 border-slate-700 mt-1 font-mono"
              />
            </div>

            <div>
              <Label htmlFor="stock">Stock Quantity</Label>
              <Input
                id="stock"
                type="number"
                value={stock}
                onChange={(e) => setStock(e.target.value)}
                placeholder="1"
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>

            <div>
              <Label htmlFor="features">Features (comma-separated)</Label>
              <Input
                id="features"
                value={features}
                onChange={(e) => setFeatures(e.target.value)}
                placeholder="10K Followers, Aged Account, Verified"
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>

            <Button type="submit" className="w-full bg-violet-500 hover:bg-violet-600 py-6">
              List Product
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};