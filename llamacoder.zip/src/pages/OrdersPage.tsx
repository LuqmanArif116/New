import React from 'react';
import { Package } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { User } from '../types';
import { formatDateTime } from '../utils/helpers';

interface OrdersPageProps {
  user: User | null;
}

export const OrdersPage: React.FC<OrdersPageProps> = ({ user }) => {
  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to view orders</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-3">
        <Package className="w-8 h-8" /> My Orders
      </h1>

      {user.orders.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-xl border border-slate-800">
          <Package className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <p className="text-slate-400">No orders yet. Start shopping!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {user.orders.map(order => (
            <Card key={order.id} className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{order.productName}</CardTitle>
                  <span className="text-amber-400 font-bold">${order.price.toFixed(2)}</span>
                </div>
                <CardDescription>
                  Purchased: {formatDateTime(order.purchasedAt)}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-800 rounded-lg p-4">
                  <p className="text-sm text-slate-400 mb-2">Account Credentials:</p>
                  <pre className="text-sm whitespace-pre-wrap bg-slate-900 p-3 rounded-lg">{order.credentials}</pre>
                </div>
                <p className="text-sm text-slate-400 mt-4">{order.deliveryInfo}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};