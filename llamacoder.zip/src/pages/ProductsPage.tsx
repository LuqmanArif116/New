import React, { useState } from 'react';
import { Shield, Search } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { ProductCard } from '../components/ProductCard';
import { Product, User } from '../types';

interface ProductsPageProps {
  products: Product[];
  user: User | null;
  onNavigate: (page: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({
  products,
  user,
  onNavigate,
  onSelectProduct,
  onAddToCart
}) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'verified'>('all');
  const [platformFilter, setPlatformFilter] = useState<string>('all');

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase());
    const matchesVerified = filter === 'all' || (filter === 'verified' && p.isVerified);
    const matchesPlatform = platformFilter === 'all' || p.platform === platformFilter;
    return matchesSearch && matchesVerified && matchesPlatform;
  });

  const sortedProducts = [
    ...filteredProducts.filter(p => p.isVerified),
    ...filteredProducts.filter(p => !p.isVerified)
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">All Products</h1>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-slate-800 border-slate-700 pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button onClick={() => setFilter('all')} className={filter === 'all' ? 'bg-violet-500' : 'bg-slate-800'}>
              All
            </Button>
            <Button onClick={() => setFilter('verified')} className={filter === 'verified' ? 'bg-emerald-500' : 'bg-slate-800'}>
              <Shield className="w-4 h-4 mr-2" /> Verified
            </Button>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          {['all', 'facebook', 'instagram', 'linkedin', 'threads'].map(platform => (
            <Button
              key={platform}
              onClick={() => setPlatformFilter(platform)}
              className={platformFilter === platform ? 'bg-violet-500' : 'bg-slate-800'}
            >
              {platform.charAt(0).toUpperCase() + platform.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {sortedProducts.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            user={user}
            onSelect={onSelectProduct}
            onNavigate={onNavigate}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>

      {sortedProducts.length === 0 && (
        <div className="text-center py-12 text-slate-400">No products found.</div>
      )}
    </div>
  );
};