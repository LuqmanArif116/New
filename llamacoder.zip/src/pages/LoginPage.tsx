import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { User } from '../types';
import { VERIFIED_SELLER_KEYS } from '../utils/constants';
import { generateId } from '../utils/helpers';

interface LoginPageProps {
  onLogin: (user: User) => void;
  onNavigate: (page: string) => void;
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onNavigate, onNotify }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegister, setIsRegister] = useState(false);
  const [verificationKey, setVerificationKey] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password) {
      onNotify('Please fill all fields', 'error');
      return;
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const existingUser = users.find((u: User) => u.email === email);

    if (isRegister) {
      if (existingUser) {
        onNotify('Email already registered', 'error');
        return;
      }

      const isVerifiedSeller = VERIFIED_SELLER_KEYS.includes(verificationKey);
      const newUser: User = {
        id: generateId(),
        email,
        password,
        role: isVerifiedSeller ? 'verified_seller' : 'buyer',
        balance: 0,
        favorites: [],
        orders: [],
        products: [],
        createdAt: Date.now()
      };

      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      onLogin(newUser);
      onNotify(isVerifiedSeller ? 'Registered as Verified Seller!' : 'Registered successfully!', 'success');
      onNavigate('home');
    } else {
      if (!existingUser || existingUser.password !== password) {
        onNotify('Invalid email or password', 'error');
        return;
      }
      localStorage.setItem('currentUser', JSON.stringify(existingUser));
      onLogin(existingUser);
      onNotify('Login successful!', 'success');
      onNavigate('home');
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-2xl text-center">{isRegister ? 'Create Account' : 'Welcome Back'}</CardTitle>
          <CardDescription className="text-center">
            {isRegister ? 'Join SocialMart today' : 'Login to your account'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="bg-slate-800 border-slate-700 mt-1"
              />
            </div>
            {isRegister && (
              <div>
                <Label htmlFor="verificationKey">Verification Key (Optional - for Sellers)</Label>
                <Input
                  id="verificationKey"
                  type="text"
                  value={verificationKey}
                  onChange={(e) => setVerificationKey(e.target.value)}
                  placeholder="Enter seller verification key"
                  className="bg-slate-800 border-slate-700 mt-1"
                />
                <p className="text-xs text-slate-500 mt-1">Leave empty to register as Buyer</p>
              </div>
            )}
            <Button type="submit" className="w-full bg-violet-500 hover:bg-violet-600 py-6">
              {isRegister ? 'Create Account' : 'Login'}
            </Button>
          </form>
          <div className="mt-4 text-center">
            <button onClick={() => setIsRegister(!isRegister)} className="text-violet-400 hover:text-violet-300 text-sm">
              {isRegister ? 'Already have an account? Login' : "Don't have an account? Register"}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};