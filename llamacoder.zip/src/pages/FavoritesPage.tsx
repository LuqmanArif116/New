import React from 'react';
import { Heart } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { Product, User } from '../types';

interface FavoritesPageProps {
  products: Product[];
  user: User | null;
  onNavigate: (page: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onUpdateUser: (user: User) => void;
}

export const FavoritesPage: React.FC<FavoritesPageProps> = ({
  products,
  user,
  onNavigate,
  onSelectProduct,
  onAddToCart,
  onUpdateUser
}) => {
  if (!user) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400">Please login to view favorites</p>
      </div>
    );
  }

  const favoriteProducts = products.filter(p => user.favorites.includes(p.id));

  const handleToggleFavorite = (productId: string) => {
    const updatedUser = {
      ...user,
      favorites: user.favorites.includes(productId)
        ? user.favorites.filter(id => id !== productId)
        : [...user.favorites, productId]
    };
    onUpdateUser(updatedUser);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-3">
        <Heart className="w-8 h-8 text-pink-500" /> My Favorites
      </h1>

      {favoriteProducts.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-xl border border-slate-800">
          <Heart className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <p className="text-slate-400">No favorites yet. Browse products and add some!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {favoriteProducts.map(product => (
            <div key={product.id} className="relative">
              <ProductCard
                product={product}
                user={user}
                onSelect={onSelectProduct}
                onNavigate={onNavigate}
                onAddToCart={onAddToCart}
              />
              <button
                onClick={() => handleToggleFavorite(product.id)}
                className="absolute top-2 left-2 bg-pink-500 p-2 rounded-full hover:bg-pink-600 transition-colors"
              >
                <Heart className="w-4 h-4 fill-white" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};