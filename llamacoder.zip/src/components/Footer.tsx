import React from 'react';
import { Send, Store } from 'lucide-react';
import { TELEGRAM_USERNAME } from '../utils/constants';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-violet-500 to-fuchsia-500 p-2 rounded-lg">
              <Store className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
              SocialMart
            </span>
          </div>
          
          <a
            href={`https://t.me/${TELEGRAM_USERNAME}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 px-4 py-2 rounded-lg transition-colors"
          >
            <Send className="w-4 h-4" />
            <span>Contact Support</span>
          </a>
        </div>
        
        <div className="text-center text-slate-500 text-sm mt-6">
          <p>© 2024 SocialMart. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};