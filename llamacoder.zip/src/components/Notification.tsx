import React from 'react';

interface NotificationProps {
  notification: { message: string; type: 'success' | 'error' | 'info' } | null;
}

export const Notification: React.FC<NotificationProps> = ({ notification }) => {
  if (!notification) return null;

  const bgColor = {
    success: 'bg-emerald-500',
    error: 'bg-red-500',
    info: 'bg-sky-500'
  }[notification.type];

  return (
    <div className={`fixed top-4 right-4 z-50 ${bgColor} text-white px-6 py-4 rounded-lg shadow-2xl max-w-sm`}>
      {notification.message}
    </div>
  );
};