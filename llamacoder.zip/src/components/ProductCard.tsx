import React from 'react';
import { Check, Eye, Star, ShoppingCart } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Product, User as UserType } from '../types';
import { formatPrice, truncateText } from '../utils/helpers';
import { PLATFORM_COLORS, PLATFORM_ICONS } from '../utils/constants';

interface ProductCardProps {
  product: Product;
  user: UserType | null;
  onSelect: (product: Product) => void;
  onNavigate: (page: string) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  user,
  onSelect,
  onNavigate,
  onAddToCart
}) => {
  const platformColor = PLATFORM_COLORS[product.platform] || 'from-slate-600 to-slate-700';
  const platformIcon = PLATFORM_ICONS[product.platform] || '📱';

  return (
    <Card className="bg-slate-900 border-slate-800 hover:border-violet-500 transition-all duration-300 overflow-hidden">
      <div className={`h-28 bg-gradient-to-br ${platformColor} flex items-center justify-center relative`}>
        <span className="text-4xl">{platformIcon}</span>
        {product.isVerified && (
          <div className="absolute top-2 right-2 bg-emerald-500 text-xs px-2 py-1 rounded-full flex items-center gap-1">
            <Check className="w-3 h-3" /> Verified
          </div>
        )}
        {product.stock <= 3 && product.stock > 0 && (
          <div className="absolute top-2 left-2 bg-red-500 text-xs px-2 py-1 rounded-full">
            Only {product.stock} left!
          </div>
        )}
      </div>
      
      <CardHeader className="pb-2">
        <CardTitle className="text-lg line-clamp-1">{product.name}</CardTitle>
        <CardDescription className="text-slate-400 line-clamp-2">
          {truncateText(product.description, 80)}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pb-2">
        <div className="flex items-center justify-between">
          <p className="text-amber-400 font-bold text-2xl">{formatPrice(product.price)}</p>
          <div className="flex items-center gap-1 text-slate-400 text-sm">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span>{product.soldCount} sold</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mt-3">
          {product.features.slice(0, 3).map((feature, i) => (
            <span key={i} className="text-xs bg-slate-800 px-2 py-1 rounded-full text-slate-300">
              {feature}
            </span>
          ))}
        </div>
      </CardContent>
      
      <CardFooter className="gap-2">
        <Button
          onClick={() => { onSelect(product); onNavigate('product-detail'); }}
          className="flex-1 bg-violet-500 hover:bg-violet-600"
        >
          <Eye className="w-4 h-4 mr-2" /> View
        </Button>
        {user && product.stock > 0 && (
          <Button onClick={() => onAddToCart(product)} className="bg-emerald-500 hover:bg-emerald-600">
            <ShoppingCart className="w-4 h-4" />
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};