import React from 'react';
import { Store, Send, LogOut, Menu, X, Home, ShoppingBag, Wallet, Clock, Settings, User, ShoppingCart } from 'lucide-react';
import { Button } from './ui/button';
import { User as UserType } from '../types';
import { TELEGRAM_USERNAME } from '../utils/constants';

interface HeaderProps {
  user: UserType | null;
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  mobileMenuOpen: boolean;
  onToggleMobile: () => void;
  cartCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  currentPage,
  onNavigate,
  onLogout,
  mobileMenuOpen,
  onToggleMobile,
  cartCount
}) => {
  const navItems = user
    ? [
        { icon: <Home className="w-4 h-4" />, label: 'Home', page: 'home' },
        { icon: <ShoppingBag className="w-4 h-4" />, label: 'Products', page: 'products' },
        { icon: <Wallet className="w-4 h-4" />, label: 'Deposit', page: 'deposit' },
        { icon: <Clock className="w-4 h-4" />, label: 'Orders', page: 'orders' }
      ]
    : [
        { icon: <Home className="w-4 h-4" />, label: 'Home', page: 'home' },
        { icon: <ShoppingBag className="w-4 h-4" />, label: 'Products', page: 'products' }
      ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-violet-500 to-fuchsia-500 p-2 rounded-lg">
            <Store className="w-6 h-6" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
            SocialMart
          </span>
        </div>

        <nav className="hidden lg:flex items-center gap-2">
          {navItems.map(item => (
            <button
              key={item.page}
              onClick={() => onNavigate(item.page)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                currentPage === item.page
                  ? 'bg-violet-500 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              {item.icon}
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <a
            href={`https://t.me/${TELEGRAM_USERNAME}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 px-4 py-2 rounded-lg transition-colors"
          >
            <Send className="w-4 h-4" />
            <span className="text-sm hidden xl:block">Telegram</span>
          </a>
          
          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('cart')}
                className="relative bg-slate-800 hover:bg-slate-700 p-2 rounded-lg transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
              
              <div className="bg-amber-500 px-4 py-2 rounded-lg">
                <span className="font-bold text-white">${user.balance.toFixed(2)}</span>
              </div>
              
              <button onClick={onLogout} className="bg-red-500 hover:bg-red-600 p-2 rounded-lg transition-colors">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Button onClick={() => onNavigate('login')} className="bg-violet-500 hover:bg-violet-600">
              <User className="w-4 h-4 mr-2" /> Login
            </Button>
          )}
        </div>

        <button className="lg:hidden p-2 bg-slate-800 rounded-lg" onClick={onToggleMobile}>
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>
    </header>
  );
};