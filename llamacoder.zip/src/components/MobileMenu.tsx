import React from 'react';
import { Home, ShoppingBag, Wallet, Clock, Heart, Settings, Store, Send, LogOut, ShoppingCart, User } from 'lucide-react';
import { Button } from './ui/button';
import { User as UserType } from '../types';
import { TELEGRAM_USERNAME } from '../utils/constants';

interface MobileMenuProps {
  user: UserType | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  cartCount: number;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({ user, onNavigate, onLogout, cartCount }) => {
  const menuItems = user
    ? [
        { icon: <Home className="w-5 h-5" />, label: 'Home', page: 'home' },
        { icon: <ShoppingBag className="w-5 h-5" />, label: 'Products', page: 'products' },
        { icon: <ShoppingCart className="w-5 h-5" />, label: `Cart (${cartCount})`, page: 'cart' },
        { icon: <Wallet className="w-5 h-5" />, label: 'Deposit', page: 'deposit' },
        { icon: <Clock className="w-5 h-5" />, label: 'Orders', page: 'orders' },
        { icon: <Heart className="w-5 h-5" />, label: 'Favorites', page: 'favorites' },
        { icon: <Store className="w-5 h-5" />, label: 'Seller Panel', page: 'seller' },
        { icon: <Settings className="w-5 h-5" />, label: 'Settings', page: 'settings' }
      ]
    : [
        { icon: <Home className="w-5 h-5" />, label: 'Home', page: 'home' },
        { icon: <ShoppingBag className="w-5 h-5" />, label: 'Products', page: 'products' }
      ];

  return (
    <div className="lg:hidden bg-slate-900 border-t border-slate-800 p-4 space-y-2">
      {menuItems.map(item => (
        <button
          key={item.page}
          onClick={() => onNavigate(item.page)}
          className="flex items-center gap-3 w-full px-4 py-3 rounded-lg hover:bg-slate-800 transition-colors text-left"
        >
          {item.icon}
          <span>{item.label}</span>
        </button>
      ))}
      
      <a
        href={`https://t.me/${TELEGRAM_USERNAME}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 bg-sky-500 px-4 py-3 rounded-lg w-full mt-4"
      >
        <Send className="w-5 h-5" />
        <span>Contact Telegram</span>
      </a>
      
      {user ? (
        <div className="flex items-center justify-between bg-slate-800 px-4 py-3 rounded-lg mt-2">
          <span className="text-amber-400 font-bold">${user.balance.toFixed(2)}</span>
          <button onClick={onLogout} className="text-red-400 flex items-center gap-2">
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      ) : (
        <Button onClick={() => onNavigate('login')} className="w-full bg-violet-500 hover:bg-violet-600 mt-2">
          <User className="w-5 h-5 mr-2" /> Login
        </Button>
      )}
    </div>
  );
};