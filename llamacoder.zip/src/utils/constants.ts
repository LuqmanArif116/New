import { Product } from '../types';

export const DEPOSIT_KEYS: string[] = [
  '4847383686197933837',
  '38383978729900282878',
  '9384091786864868683686'
];

export const VERIFIED_SELLER_KEYS: string[] = [
  '48474947383638518584647363',
  '4947484648463383628510072',
  '085947483624826285282528262',
  '384748474744'
];

export const TELEGRAM_USERNAME = 'Dark_shop_2026';

export const PLATFORMS = ['facebook', 'instagram', 'linkedin', 'threads'] as const;

export const PLATFORM_COLORS: Record<string, string> = {
  facebook: 'from-blue-600 to-blue-700',
  instagram: 'from-pink-500 via-purple-500 to-orange-400',
  linkedin: 'from-sky-600 to-blue-700',
  threads: 'from-slate-800 to-slate-900'
};

export const PLATFORM_ICONS: Record<string, string> = {
  facebook: '📘',
  instagram: '📸',
  linkedin: '💼',
  threads: '🧵'
};

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Facebook Business Account - 10K Followers',
    platform: 'facebook',
    price: 29.99,
    description: 'Aged Facebook business account with 10,000+ real followers. Perfect for business promotion.',
    sellerId: 'seller1',
    sellerEmail: 'verified_pro@seller.com',
    isVerified: true,
    credentials: 'Email: fb_business_10k@outlook.com\nPassword: FBSecure2024!',
    deliveryInfo: 'Instant delivery - credentials displayed immediately',
    stock: 5,
    soldCount: 23,
    createdAt: Date.now() - 86400000 * 5,
    features: ['10K+ Followers', 'Business Account', 'Aged 2+ Years']
  },
  {
    id: '2',
    name: 'Instagram Influencer - 50K Followers',
    platform: 'instagram',
    price: 149.99,
    description: 'High-engagement Instagram influencer account with 50,000+ active followers.',
    sellerId: 'seller1',
    sellerEmail: 'verified_pro@seller.com',
    isVerified: true,
    credentials: 'Username: influencer_50k\nPassword: InstaSecure#2024',
    deliveryInfo: 'Instant delivery - full credentials included',
    stock: 2,
    soldCount: 15,
    createdAt: Date.now() - 86400000 * 3,
    features: ['50K+ Followers', 'High Engagement', 'Lifestyle Niche']
  },
  {
    id: '3',
    name: 'LinkedIn Premium Recruiter',
    platform: 'linkedin',
    price: 79.99,
    description: 'LinkedIn Premium Recruiter account with 5000+ connections.',
    sellerId: 'seller2',
    sellerEmail: 'normal_user@seller.com',
    isVerified: false,
    credentials: 'Email: linkedin_recruiter@outlook.com\nPassword: LinkedPro2024!',
    deliveryInfo: 'Instant delivery - Premium active for 6 months',
    stock: 3,
    soldCount: 8,
    createdAt: Date.now() - 86400000 * 7,
    features: ['5K+ Connections', 'Premium Active', 'Recruiter Tools']
  },
  {
    id: '4',
    name: 'Threads Verified - Blue Badge',
    platform: 'threads',
    price: 199.99,
    description: 'Verified Threads account with blue verification badge.',
    sellerId: 'seller1',
    sellerEmail: 'verified_pro@seller.com',
    isVerified: true,
    credentials: 'Username: verified_threads\nPassword: ThreadsVerified!2024',
    deliveryInfo: 'Instant delivery - verified status guaranteed',
    stock: 1,
    soldCount: 42,
    createdAt: Date.now() - 86400000 * 2,
    features: ['Verified Badge', '10K+ Followers', 'Full Access']
  }
];