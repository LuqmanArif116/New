import { useState, useEffect, useCallback } from 'react';
import { User } from '../types';
import { getUserFromStorage, saveUserToStorage } from '../utils/helpers';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = getUserFromStorage();
    setUser(savedUser);
    setLoading(false);
  }, []);

  const login = useCallback((userData: User) => {
    setUser(userData);
    saveUserToStorage(userData);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('currentUser');
  }, []);

  const updateUser = useCallback((updatedUser: User) => {
    setUser(updatedUser);
    saveUserToStorage(updatedUser);
  }, []);

  return { user, loading, login, logout, updateUser, setUser };
};