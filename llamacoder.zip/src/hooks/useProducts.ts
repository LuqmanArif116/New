import { useState, useEffect } from 'react';
import { Product } from '../types';
import { SAMPLE_PRODUCTS } from '../utils/constants';
import { getProductsFromStorage, saveProductsToStorage } from '../utils/helpers';

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const savedProducts = getProductsFromStorage();
    setProducts([...SAMPLE_PRODUCTS, ...savedProducts]);
  }, []);

  const addProduct = (product: Product) => {
    const customProducts = products.filter(p => !SAMPLE_PRODUCTS.find(sp => sp.id === p.id));
    const newProducts = [...customProducts, product];
    saveProductsToStorage(newProducts);
    setProducts([...SAMPLE_PRODUCTS, ...newProducts]);
  };

  return { products, setProducts, addProduct };
};