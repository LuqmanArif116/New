export interface User {
  id: string;
  email: string;
  password: string;
  role: 'buyer' | 'verified_seller';
  balance: number;
  favorites: string[];
  orders: Order[];
  products: Product[];
  createdAt: number;
}

export interface Product {
  id: string;
  name: string;
  platform: 'facebook' | 'instagram' | 'linkedin' | 'threads';
  price: number;
  description: string;
  sellerId: string;
  sellerEmail: string;
  isVerified: boolean;
  credentials: string;
  deliveryInfo: string;
  stock: number;
  soldCount: number;
  createdAt: number;
  features: string[];
}

export interface Order {
  id: string;
  productId: string;
  productName: string;
  platform: string;
  price: number;
  credentials: string;
  deliveryInfo: string;
  purchasedAt: number;
  sellerEmail: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}