import React, { useState, useEffect } from 'react';
import { useAuth } from './hooks/useAuth';
import { useNotification } from './hooks/useNotification';
import { useProducts } from './hooks/useProducts';
import { Notification } from './components/Notification';
import { Header } from './components/Header';
import { MobileMenu } from './components/MobileMenu';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { LoginPage } from './pages/LoginPage';
import { DepositPage } from './pages/DepositPage';
import { WithdrawPage } from './pages/WithdrawPage';
import { OrdersPage } from './pages/OrdersPage';
import { FavoritesPage } from './pages/FavoritesPage';
import { CartPage } from './pages/CartPage';
import { SellerPanel } from './pages/SellerPanel';
import { SettingsPage } from './pages/SettingsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { Product, User, CartItem } from './types';

export default function App() {
  const { user, login, logout, updateUser } = useAuth();
  const { notification, showNotification } = useNotification();
  const { products, addProduct } = useProducts();
  
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);

  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    if (page !== 'product-detail') {
      setSelectedProduct(null);
    }
  };

  const handleAddToCart = (product: Product) => {
    const existingItem = cart.find(item => item.product.id === product.id);
    if (existingItem) {
      setCart(cart.map(item =>
        item.product.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
    showNotification('Added to cart!', 'success');
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter(item => item.product.id !== productId));
    showNotification('Removed from cart', 'info');
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
    } else {
      setCart(cart.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      ));
    }
  };

  const handlePurchase = () => {
    if (!user) return;
    
    const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    if (user.balance < total) {
      showNotification('Insufficient balance', 'error');
      return;
    }

    const newOrders = cart.map(item => ({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      productId: item.product.id,
      productName: item.product.name,
      platform: item.product.platform,
      price: item.product.price,
      credentials: item.product.credentials,
      deliveryInfo: item.product.deliveryInfo,
      purchasedAt: Date.now(),
      sellerEmail: item.product.sellerEmail
    }));

    const updatedUser = {
      ...user,
      balance: user.balance - total,
      orders: [...user.orders, ...newOrders]
    };

    updateUser(updatedUser);
    setCart([]);
    localStorage.removeItem('cart');
    showNotification('Purchase successful! Check your orders.', 'success');
    handleNavigate('orders');
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            products={products}
            user={user}
            onNavigate={handleNavigate}
            onSelectProduct={setSelectedProduct}
            onAddToCart={handleAddToCart}
          />
        );
      case 'products':
        return (
          <ProductsPage
            products={products}
            user={user}
            onNavigate={handleNavigate}
            onSelectProduct={setSelectedProduct}
            onAddToCart={handleAddToCart}
          />
        );
      case 'login':
        return (
          <LoginPage
            onLogin={login}
            onNavigate={handleNavigate}
            onNotify={showNotification}
          />
        );
      case 'deposit':
        return (
          <DepositPage
            user={user}
            onUpdateUser={updateUser}
            onNotify={showNotification}
          />
        );
      case 'withdraw':
        return (
          <WithdrawPage
            user={user}
            onUpdateUser={updateUser}
            onNotify={showNotification}
          />
        );
      case 'orders':
        return <OrdersPage user={user} />;
      case 'favorites':
        return (
          <FavoritesPage
            products={products}
            user={user}
            onNavigate={handleNavigate}
            onSelectProduct={setSelectedProduct}
            onAddToCart={handleAddToCart}
            onUpdateUser={updateUser}
          />
        );
      case 'cart':
        return (
          <CartPage
            cart={cart}
            user={user}
            onNavigate={handleNavigate}
            onRemove={handleRemoveFromCart}
            onUpdateQuantity={handleUpdateCartQuantity}
            onPurchase={handlePurchase}
          />
        );
      case 'seller':
        return (
          <SellerPanel
            user={user}
            onNavigate={handleNavigate}
            onAddProduct={addProduct}
            onNotify={showNotification}
          />
        );
      case 'settings':
        return (
          <SettingsPage
            user={user}
            onNavigate={handleNavigate}
            onLogout={logout}
          />
        );
      case 'product-detail':
        return selectedProduct ? (
          <ProductDetailPage
            product={selectedProduct}
            user={user}
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onNotify={showNotification}
            onUpdateUser={updateUser}
          />
        ) : null;
      default:
        return (
          <HomePage
            products={products}
            user={user}
            onNavigate={handleNavigate}
            onSelectProduct={setSelectedProduct}
            onAddToCart={handleAddToCart}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      <Notification notification={notification} />
      
      <Header
        user={user}
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onLogout={logout}
        mobileMenuOpen={mobileMenuOpen}
        onToggleMobile={() => setMobileMenuOpen(!mobileMenuOpen)}
        cartCount={cartCount}
      />
      
      {mobileMenuOpen && (
        <MobileMenu
          user={user}
          onNavigate={handleNavigate}
          onLogout={logout}
          cartCount={cartCount}
        />
      )}
      
      <main className="flex-1 max-w-7xl mx-auto px-4 py-8 w-full">
        {renderPage()}
      </main>
      
      <Footer />
    </div>
  );
}